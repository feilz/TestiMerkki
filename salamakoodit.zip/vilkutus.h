int8_t kirkkaus[32];

void vilkutus(void);
